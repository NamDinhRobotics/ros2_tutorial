^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_rclcpp_cbg_executor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.2 (2021-04-26)
-------------------

0.11.1 (2021-04-12)
-------------------
* Fix clang warnings about type mismatches. (`#309 <https://github.com/ros2/examples/issues/309>`_)
* Contributors: Chris Lalancette

0.11.0 (2021-04-06)
-------------------
* Support for cbg_executor package on QNX (`#305 <https://github.com/ros2/examples/issues/305>`_)
* Contributors: joshua-qnx

0.10.3 (2021-03-18)
-------------------
* Demo for callback-group-level executor concept. (`#302 <https://github.com/ros2/examples/issues/302>`_)
* Contributors: Ralph Lange
