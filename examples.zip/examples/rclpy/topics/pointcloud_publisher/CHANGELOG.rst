^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package examples_rclpy_pointcloud_publisher
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

0.11.2 (2021-04-26)
-------------------
* Use underscores instead of dashes in setup.cfg (`#310 <https://github.com/ros2/examples/issues/310>`_)
* Contributors: Ivan Santiago Paunovic

0.11.1 (2021-04-12)
-------------------

0.11.0 (2021-04-06)
-------------------

0.10.3 (2021-03-18)
-------------------
* add pointcloud publisher example (`#276 <https://github.com/ros2/examples/issues/276>`_)
* Contributors: Evan Flynn
